<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_tanja_kunz_traveler
 */

get_header();
?>

      <div class="row">

        <div class="col-sm-8 blog-main">

          <?php if(have_posts()) :  ?>  
            <?php while(have_posts()) : the_post(); ?>
              <div class="blog-post">
                <h2 class="blog-post-title">
                  <a href="<?php the_permalink(); ?>">
                  <?php the_title(); ?> </h2></a>
                <p class="blog-post-meta"><?php the_time('F j, Y g:i a'); ?>
                <a href="<?php echo get_author_posts_url(get_the_author_meta('ID')); ?>"><?php the_author(); ?></a></p>

                <?php the_content(); ?>
              </div>
            <?php endwhile; ?> 

          <?php else : ?> 
              <p><?php__('No Posts Found'); ?></p>
          <?php endif; ?>          

        </div>

        <div class="col-sm-3 col-sm-offset-1 blog-sidebar">
          <div class="sidebar-module sidebar-module-inset">
            <div>
              <img src="https://thetravellette.com/wp-content/uploads/2018/04/ueber-mich-thetravellette-1.png" id="ueber">
            </div>
            <h4>About</h4>
            <p>Etiam porta <em>sem malesuada magna</em> mollis euismod. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.</p>
          </div>
          <?php
            if(is_active_sidebar('sidebar')):
           dynamic_sidebar('sidebar');
           endif;  
          ?>
        </div>

      </div> <!-- Row -->

    </div> <!-- Container-Fluid -->
   
    

<?php get_footer(); ?>