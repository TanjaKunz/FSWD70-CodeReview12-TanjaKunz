<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  
  <meta name="description" content="<?php bloginfo('description'); ?>">
  <title><?php bloginfo('name'); ?></title>

  <!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

  <!-- Custom styles for this template -->
  <link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <?php wp_head(); ?>
</head>
<body>
  <header>  
  <div class="site-branding">
      <?php
      the_custom_logo();
      if (is_front_page() && is_home() ) :
        ?>
        <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
        <?php
      else :
        ?>
        <p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
        <?php
      endif;
      $cr12_tanja_kunz_traveler_description = get_bloginfo( 'description', 'display' );
      if ( $cr12_tanja_kunz_traveler_description || is_customize_preview() ) :
        ?>
        <p class="site-description"><?php echo $cr12_tanja_kunz_traveler_description; /* WPCS: xss ok. */ ?></p>
      <?php endif; ?>
    </div><!-- .site-branding -->
  <nav class="navbar navbar-expand-md navbar-light bg-light" role="navigation" id="navi">

         <div class="container">

        <!-- Brand and toggle get grouped for better mobile display -->

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">

            <span class="navbar-toggler-icon"></span>

        </button>

            <?php

            wp_nav_menu( array(

                'theme_location'    => 'primary',
                'depth'             => 2, // 1 = no dropdowns, 2 = dropdown
                'container'         => 'div',
                'container_class'   => 'collapse navbar-collapse',
                'container_id'      => 'bs-example-navbar-collapse-1',
                'menu_class'        => 'nav navbar-nav',
                'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
                'walker'            => new WP_Bootstrap_Navwalker(),

            ) );

            ?>

        </div>

    </nav>
  </header><!-- /header -->

  <div class="row mt-5">
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" id="carousel">
      <div class="carousel-inner" id="slides">
        <section class="carousel-item active d-flex" id="slide1">
          <img class="d-block w-100" src="https://cdn.pixabay.com/photo/2018/08/11/10/23/london-3598397_960_720.jpg">
          <div class="carousel-caption d-none d-md-block">
            <h3 class="m-0">Lorem Ipsum</h3>
            <h4 class="m-0">Lorem ipsum dolor sit amet, consetetur sadipscing elitr.</h4>
          </div>
        </section>
        <section class="carousel-item" id="slide2">
          <img class="d-block w-100" src="https://upload.wikimedia.org/wikipedia/commons/f/fc/The_Pont_Michel_from_the_Pont_Neuf%2C_Paris_July_2013.jpg">
          <div class="carousel-caption d-none d-md-block">
            <h3 class="m-0">Lorem Ipsum</h3>
            <h4 class="m-0">Lorem ipsum dolor sit amet, consetetur sadipscing elitr.</h4>
          </div>
        </section>
      </div>
    </div> <!------ End Carousel ----->

    <div class="row mt-5" id="blogs">


        <?php if(have_posts()) : ?>
          <?php while(have_posts()): the_post(); ?>
            
            <div class="col-4 p-5">
              <?php if(has_post_thumbnail()) : ?>
                <a href="<?php the_permalink(); ?>"><img class="card-img-top" alt="Image" src="<?php the_post_thumbnail(); ?>  </a>
              <?php endif; ?>
              <div class="card-body">
                <h4 class="card-title"><?php the_title(); ?></h4>
                <p class="card-text"><?php the_excerpt(); ?></p>
                <p><?php the_time('F y, Y g:i a'); ?> - <a href="<?php the_permalink(); ?>">Read more</a></p>
              </div>
            </div>
          <?php endwhile; ?>
        <?php else : ?>
          <p><?php__('No Posts Found'); ?></p>
        <?php endif; ?>    
      
    </div>
  
  
</div>

<?php get_footer(); ?>