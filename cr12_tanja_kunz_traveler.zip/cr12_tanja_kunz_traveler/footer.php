	</div><!-- #content -->

	<footer class="footer fixed-bottom py-3" id="footer">
         <div class="container text-center">
            <span class="text-muted">&copy; <?php echo Date('Y'); ?> <?php bloginfo('name'); ?></span>
            <p class="d-inline">
	       <a href="#">Back to top</a>
	     </p>
         </div>
      </footer>

</div><!-- #page -->

<?php wp_footer(); ?>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
 </body>
</html>